package com.example.basicgrid;

public class SlidingGetSet {
    String name;
    public SlidingGetSet(String name){
    	 this.name= name;
    }
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}